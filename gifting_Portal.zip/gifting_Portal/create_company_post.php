
<?php
include('Config.php');
include('db_functions.php');
$dbFunctions_obj = new dbFunctions();
$id = $_GET['id'];
if (isset($_GET['id'])) {
    $sql    = "DELETE FROM company_table WHERE id =$id";
    $result = $db->query($sql);
    if($result){
        header('Location: create_company.php');
    }
}
// if(isset($_POST['submit'])){
//     $companyname = $_POST['companyname'];
//     $brances     = $_POST['brances'];
//     $obj = $dbFunctions_obj->createCompany($companyname, $brances);
//     if($obj){
//         echo "inserted";
//         header('Location: create_company.php');
//     }else{
//         echo "not inserted";
//     }
// }
if(isset($_POST['submit_company'])){
    $companyname = $_POST['companyname'];
    $brances     = $_POST['brances'];
    $branch = explode(",",$brances);
    $obj = $dbFunctions_obj->createCompany($companyname, $branch);
    if($obj){
        echo "inserted";
        //header('Location: create_company.php');
    }else{
        echo "not inserted";die;
    }
}

if (isset($_POST['Invitees_bulk'])) {
	$num =  $_POST['h'];
	for($i=0;$i<=$num;$i++)
    {
        $name       = $_POST["name_$i"];
        $email    = $_POST["email_$i"];
        $phone_no = $_POST["phone_$i"];
        if($name=='' || $email=='' || $phone_no==''){
                    //echo 'name is empty';
        } else {
            //echo $sqlQuery = " INSERT INTO members_table(salutation, name, emailId, phone_num,groupId,father_name,father_num,alone,spose,Child,others) Values('$salutation','$name', '$email','$phone_no','$group_id','$father_name','$father_num','$checkbox1','$checkbox2','$checkbox3','$checkbox4')";die;
            $sqlQuery = " INSERT INTO distributer_table(name, emailId, phone_num) Values('$name', '$email','$phone_no')";
            $result = mysqli_query($db, $sqlQuery);
        }					
    }
    header('Location: create_distributer.php');
}
if (isset($_POST['customer_page'])) {
	$num =  $_POST['h'];
	for($i=0;$i<=$num;$i++)
    {
        $name     = $_POST["name_$i"];
        $email    = $_POST["email_$i"];
        $phone_no = $_POST["phone_$i"];
        $des      = $_POST["des_$i"];
        $company_name = $_POST["selected_company"][$i];
        $branch = $_POST["selected_branches"][$i];
        			
        if($name=='' || $email=='' || $phone_no==''|| $des==''){
                    //echo 'name is empty';
        } else {
            //echo $sqlQuery = " INSERT INTO members_table(salutation, name, emailId, phone_num,groupId,father_name,father_num,alone,spose,Child,others) Values('$salutation','$name', '$email','$phone_no','$group_id','$father_name','$father_num','$checkbox1','$checkbox2','$checkbox3','$checkbox4')";die;
            $sqlQuery = " INSERT INTO customer_table(name, emailId, phone_num, designation,company,branch) Values('$name', '$email','$phone_no','$des','$company_name','$branch')";
            $result = mysqli_query($db, $sqlQuery);
        }					
    }
    header('Location: create_customer.php');
}
if (isset($_POST['c_id'])) {
	$sql = "select * from company_table where company_name='".$_POST['c_id']."'";
    $res = mysqli_query($db, $sql);
    if(mysqli_num_rows($res) > 0) {
        echo "<option value=''>------- Select --------</option>";
        while($row = mysqli_fetch_object($res)) {
        echo "<option value='".$row->branches."'>".$row->branches."</option>";
        }
    }else{
        echo "empty";die;
    }
} else {
  header('location: ./');
}


?>