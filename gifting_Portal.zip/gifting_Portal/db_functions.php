<?php
//session_start();
error_reporting(E_ERROR | E_PARSE);
class dbFunctions
{
    private $conn;
    function __construct()
    {
        $servername = 'localhost';
        $dbname     = 'gifting_portal_local';
        $username   = 'root';
        $password   = '';
        // Create connection
        $conn       = new mysqli($servername, $username, $password, $dbname);
        // Check connection
        if ($conn->connect_error) {
            die('Connection failed: ' . $conn->connect_error);
        } else {
            $this->conn = $conn;
        }
    }
    public function createCompany($companyname, $brances)
    {
        foreach($brances as $brance){
            $sql = "INSERT INTO company_table (	company_name,branches) VALUES ('" . $companyname . "','" . $brance . "')";
            $result  = $this->conn->query($sql);
        }
        if ($result) {
            return true;
            //$_SESSION['message'] = 'Successfully Created Info';
        } else{
            return false;
        }
        
    }
    public function getCompanylist()
    {
        $sql    = 'SELECT * FROM company_table ORDER BY id desc ';
        $result = $this->conn->query($sql);
        return $result;
    }
    public function getDistributerlist()
    {
        $sql    = 'SELECT * FROM distributer_table ORDER BY id desc ';
        $result = $this->conn->query($sql);
        return $result;
    }
    public function admin_user_login($usename, $password, &$roleId, &$status)
    {
        
        $sql    = "SELECT * FROM `user_table` WHERE `emailId`='$usename' and `password`='$password'";
        $result = $this->conn->query($sql);
        while ($row = $result->fetch_assoc()) {
            $roleId = $row['roleId'];
            $status = $row['status'];
        }
        //echo $roleId;
        return $result;
    }
}
    