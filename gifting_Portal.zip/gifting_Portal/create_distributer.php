<?php 
//include './class/admin_invitation.php';
include('header.php');
include('db_functions.php');
$dbFunctions_obj = new dbFunctions();
//$result = $dbFunctions_obj->getDistributerlist();
?>

<script language="javascript" type="text/javascript">
var i=1;
function addRow()
{
    var tbl = document.getElementById('dynamic_field');
      var lastRow = tbl.rows.length;
      //var iteration = lastRow - 1;
      var row = tbl.insertRow(lastRow);
	  var lastRows =lastRow+1;
	  
	  //alert(lastRow);
	  var lf=document.createElement('div');
	  lf.className  = 'divs';
	  row.appendChild(lf);
	  var label = document.createElement('label');
	  var tn = document.createTextNode("Member");
	  label.className  = 'font3';
	  label.appendChild(tn); 
	  row.appendChild(label);
	  
	  var label = document.createElement('label');
	  var re = document.createTextNode(lastRows);
	  label.className  = 'font4';
	  label.appendChild(re); 
	  row.appendChild(label);

      var firstCell = row.insertCell(0);
	  var selectList = tbl.rows[0].querySelector('select');
	  var element2 = document.createElement("select");
	  firstCell.className  = 'mem_table_td_sal';
	  var element2 = selectList.cloneNode(true);
	  element2.id = 'selected-item'+lastRow;
	  firstCell.appendChild(element2);

      var secondCell = row.insertCell(1);
      var el2 = document.createElement('input');
      el2.type = 'text';
	  secondCell.className  = 'mem_table_td_name ';
      el2.name = 'name_' + i;
      el2.className = 'error_msg_name';
      el2.placeholder ="Name";
      el2.id = 'name_' + i;
      el2.size = 100;
      el2.maxlength = 200;
      secondCell.appendChild(el2);
	//   var label = document.createElement('div');
	// 	var tn = document.createTextNode("");
	// 	label.appendChild(tn); 
	// 	secondCell.appendChild(label);
		var label = document.createElement('div');
		var tn = document.createTextNode("");
		label.className  = 'error_messg';
		label.appendChild(tn); 
		secondCell.appendChild(label);

      var thirdCell = row.insertCell(2);
      var el3 = document.createElement('input');
      el3.type = 'text';
	  thirdCell.className  = 'mem_table_td_ph error_msg';
      el3.name = 'email_' + i;
	  el3.className = 'error_msg_email';
      el3.placeholder = "Email ID";
      el3.id = 'email_' + i;
      el3.size = 100;
      el3.maxlength = 200;
      thirdCell.appendChild(el3);
	  	//   var label = document.createElement('div');
		// var tn = document.createTextNode("");
		// label.appendChild(tn); 
		// thirdCell.appendChild(label);
		var label = document.createElement('div');
		var tn = document.createTextNode("");
		label.className  = 'error_messg';
		label.appendChild(tn); 
		thirdCell.appendChild(label);
	  
	  var fourthCell = row.insertCell(3);
      var el4 = document.createElement('input');
      el4.type = 'text';
	  fourthCell.className  = 'mem_table_td_ph error_msg';
      el4.name = 'phone_' + i;
	  el4.className = 'error_msg_phone';
      el4.placeholder = "Phone No.";
      el4.id = 'phone_' + i;
      el4.size = 100;
      el4.maxlength = 200;
      fourthCell.appendChild(el4);
	//    var label = document.createElement('div');
	// 	var tn = document.createTextNode("");
	// 	label.appendChild(tn); 
	// 	fourthCell.appendChild(label);
		var label = document.createElement('div');
		var tn = document.createTextNode("");
		label.className  = 'error_messg';
		label.appendChild(tn); 
		fourthCell.appendChild(label);

        var twelethCell = row.insertCell(4);
		var el12 = document.createElement('input');
		el12.type = 'button';
		el12.className  = 'remove_but2';
		el12.setAttribute('type', 'button');
		el12.setAttribute('value', 'X');
		//ADD THE BUTTON's 'onclick' EVENT.
		el12.setAttribute('onclick', 'removeRow(this)');
		twelethCell.appendChild(el12);
		 //alert(i);
        frm.h.value=i;
		   i++;
}
// DELETE TABLE ROW.
function removeRow(oButton) {
    var empTab = document.getElementById('dynamic_field');
    empTab.deleteRow(oButton.parentNode.parentNode.rowIndex);       // BUTTON -> TD -> TR.
}
</script>
<div class="row rowfluidalignment">
    <div class="col-sm-12"> 
        <!-- Page Form Start -->
        <?php
        echo "<table class=\"user_history_table\">
            <tr>
                <th>Name</th>
                <th>Brances</th>
                <th>Action</th>
            </tr>";
            while($row = mysqli_fetch_array($result))
            {
                echo "<tr>";
                echo "<td>" . $row['company_name'] . "</td>";
                echo "<td>" . $row['branches'] . "</td>";
                echo "<td> <a href=create_company_post.php?id=".$row['id'].">Delete</td>";
                echo "</tr>";
            }
        echo "</table>";
        ?>
        <!-- Page Form End -->
    </div>
</div>
<div class='searchConteiner'>
    <div class='row rowfluidalignment'>
        <div class='col-sm-12'>
            <div class='col-sm-12 widgetDescriptionForm'>
                <div class=''>
                    <!-- Page Form Start -->
                    <form method="post" enctype="multipart/form-data" id="frm" name="frm"  post="create_company_post.php">	
                        <div class="manuallys_members">
                            <h4 class='header_title'>Create Manual distributers</h4>
                            <input type='hidden' name='Invitees_bulk' id='select_id' value="1">
                            <div class='widgetDescriptionRow2 clearfix'>
                                <div class="table-responsive">  
                                    <table id="dynamic_field" class="mem_table table table-bordered">  
                                        <tr>  
                                            <td><label class="mem_label"> 1 Member</label>
												<select name="selected_item[]" class="form-control select mar_T" style="width: 189px;">
													<option value="">Mr/Mrs/Miss</option> 
													<option value="Mr">Mr</option> 
													<option value="Mrs">Mrs</option> 
													<option value="Miss">Miss</option> 
											    </select>
											</td>  
											<td class="mar_T">
                                                <input class="error_msg_name" name="name_0" type="text" id="name_0"  maxlength="200" placeholder="Name" />
                                                <div class="discriptionErrorMsg error-span-hide red-error news"></div>
                                            </td>  
                                            <td class="mar_T">
                                                <input class="error_msg_email" name="email_0" type="email" id="email_0"  maxlength="200" placeholder="Email ID" />
                                                <div class="discriptionErrorMsg error-span-hide red-error news"></div>
                                            </td>
                                            <td class="mar_T">
                                                <input class="error_msg_phone" name="phone_0" type="number" id="phone_0"  maxlength="11" minlength="10" placeholder="Phone No." />
                                                <div class="discriptionErrorMsg error-span-hide red-error news"></div>
                                            </td>
                                        </tr>
                                    </table>  
                                    <div><input type="button" value="Add" class="dynamic_field add_fields2 btn add-bttn " onclick="addRow('dynamic_field');" />
                                </div>
                                <fieldset class='col-sm-12 form-group pull-right'>   
                                    <div class='widgetSearchButton no-search-criteria pull-right'>	
                                        <input name="submit_distributer" type="submit" value="Submit" id="submit" class='btn btn-info cust-bttn submit'/>
                                    </div>
                                </fieldset>
                            </div>
                        </div>
                        </div>
                        <label>
                            <input name="h" type="hidden" id="h" value="0" />
                        </label>
                    </form>
                    <div class='popup searchpopups' id="myModal">
                        <div class='popupremove'>
                            <span class='fa fa-remove close1' onclick=' ()'></span>
                        </div>
                        <div class=' popup-search-container'>
                            <div class='row rowfluidalignment'>
                                <div class='col-sm-12'>
                                    <div class='col-sm-12 widgetDescriptionForm'>
                                        <div class='row'>
                                            <div class='widgetDescriptionRow'>
                                            <h1 class='popup_text'> Distributer Created Sucessfully</h1>
                                            </div>
                                        </div>
                                        <!-- Popup Form Button Start -->
                                        <div class='role-makerchecker-btn'>
                                            <fieldset class='form-group'>
                                            <div class='widgetSearchButton col-sm-12 no-padding'>
                                                <input type='button' name='decline' value='OK' class='btn btn-info new-btn-chang-pass pull-right cust-bttn close1' > 
                                            </div>
                                            </fieldset>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
					</div>
                </div>
            </div>
        </div>
        <script>
			$(document).ready(function(){      
			$('#frm').on('submit', function(event){
			event.preventDefault();
			//alert("fmr 1");
			var values = new Array();
			$(".discriptionErrorMsg").empty();
			$(".error_messg").empty();
			
			  $('.error_msg_name').each(function () {
				  	if (this.value ==''){
						  console.log('diid');
						   values.push(1);
						   nameError = "Please Enter Name* ";
						$( this ).siblings()[0].innerHTML=  nameError;
                       // $(".error_messg").val(nameError);
					}
				});
				$('.error_msg_email').each(function () {
				  	  if (this.value ==''){
						   values.push(1);
						   nameError = "Please Enter Email id* ";
						$( this ).siblings()[0].innerHTML=  nameError;
					  }
				});
				$('.error_msg_phone').each(function () {
				  	  if (this.value ==''){
						   values.push(1);
						   nameError = "Please Enter Phone number* ";
						$( this ).siblings()[0].innerHTML=  nameError;
					  }
				});
				
				  if (values.length == 0){
					  $.ajax({  
						url:"create_company_post.php",  
						method:"POST",  
						data:$('#frm').serialize(),
						type:'json',
						success:function(data)  
							{ 
								i=1;
								$('.dynamic-added').remove();
								$('#frm')[0].reset();
										
								$('.popup').popup('show');
								$('.close1').click(function(){
								$('.popup').popup('hide');
								window.location.href = "create_distributer.php";
								})
							}  
						});
				  }
				//return false;
			  });
			  });
		</script>
		<script>  


                
                        
