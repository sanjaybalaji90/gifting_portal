<?php 
//include './class/admin_invitation.php';
include('header.php');
include('db_functions.php');
$dbFunctions_obj = new dbFunctions();
$result_company = $dbFunctions_obj->getCompanylist();
$result_distributer = $dbFunctions_obj->getDistributerlist();
?>
<div class='searchConteiner'>
    <div class='row rowfluidalignment'>
        <div class='col-sm-12'>
            <!-- Page Form Start -->
            <form id='eventDetails'  method='post' enctype="multipart/form-data" action="">
                <!-- <h4>Invitaion Portal <h4> -->
                <div class='col-sm-12 widgetDescriptionForm'>
                    <div class='row'>
                        <h4 class='header_title'>Event Detail</h4>
                        <div class='widgetDescriptionRow clearfix'>								
                            <fieldset class='col-sm-4 form-group'>
                                <label><span class='requiredFiled'>*</span>Name</label>
                                <input id='invitaionName' name='invitaionName' class='form-control' onblur='this.value=this.value.trim();' type='text' value='' maxlength='30' >
                                <div class='discriptionErrorMsg nameerror'>
                                </div>
                            </fieldset>
                            <fieldset class='col-sm-4 form-group'>
                                <label><span class='requiredFiled'>*</span>Distribution Date</label>
                                    <div id='datetimepicker1' class='input-append date'>
                                    <input id='eventDate' name='eventDate' data-format='dd/MM/yyyy' type='text'  readonly ></input>
                                    <span class='add-on'>     
                                        <i data-time-icon='icon-time' data-date-icon='icon-calendar'>
                                        </i>
                                    </span>
                                    </div>
                                <div class='discriptionErrorMsg dateerror'>
                                </div>
                            </fieldset>
                            <fieldset class='col-sm-4 form-group'>
                                <label><span class='requiredFiled'>*</span>Distributer Name</label>
                                <?php
                                echo "</br>";
                                 echo "<select id='selected_distributer' name='selected_distributer' style='width: 189px;' class='error_msg_company'>";
                                echo "<option value=''>Select Distributer</option>";
                                
                                                            while ($row = $result_distributer->fetch_assoc()) 
                                                            {
                                                            //unset($inv_from);
                                                            $distributer_name = $row['name'];
                                                            $distributer_id = $row['id'];
                                                            echo '<option value="'.$distributer_id.'">'.$distributer_name.'</option>';
                                                            }
                                                        echo "</select>";
                                                        ?>
                                <div class='discriptionErrorMsg distributererror'>
                                </div>
                                <br/>
                                <br/>
                            </fieldset>
                            <fieldset class='col-sm-4 form-group'>
                                <label><span class='requiredFiled'>*</span>Company</label>
                                <?php
                                echo "</br>";
                                 echo "<select id='sel2' name='selected_company[]' style='width: 189px;' class='error_msg_company'>";
                                echo "<option value=''>Select Comapany</option>";
                                                            while ($row = $result_company->fetch_assoc()) 
                                                            {
                                                            //unset($inv_from);
                                                            $company_name = $row['company_name'];
                                                            $company_id = $row['id'];
                                                            echo '<option value="'.$company_name.'">'.$company_name.'</option>';
                                                            }
                                                        echo "</select>";
                                                        ?>
                                <div class='discriptionErrorMsg companyerror'>
                                </div>
                            </fieldset>
                            <fieldset class='col-sm-4 form-group'>
                                <label><span class='requiredFiled'>*</span>Branch</label>
                                <br/>
                                <select id='selected_branches' name='selected_branches[]' style='width: 189px;' class='error_msg_branch'>
                                <option value=''>Select Branch</option></select>
                                <div class='discriptionErrorMsg brancherror'>
                                </div>
                            </fieldset>
                        </div>   
                    </div>
                    <!-- Form Button Start -->
                    <fieldset class='form-group pull-right'>
                        <div class='widgetSearchButton search-criteria'>
                            <!-- <label>Search criteria : you can use wild characters (*,%) for search</label> -->
                        </div>
                        <div class='widgetSearchButton no-search-criteria'>	
                            <input type='submit' value='Send Invitaion' name='submit' id='invitDatetime' class='btn btn-info cust-bttn submit'>
                        </div>
                    </fieldset>
                    <!-- Form Button End -->
                </div>
            </form>
        </div>
    </div>
</div>
                  <!-- Content Block End -->
            </div>
		</article>
	</body>
</html>
<script>
			$(document).ready(function(){      
                $("#sel2").change(function() {
                    //console.log('dd');
                    var country_id = $(this).val();
                    //alert(country_id);return false;
                    if(country_id != "") {
                        $.ajax({
                            url:"create_company_post.php",
                            data:{c_id:country_id},
                            type:'POST',
                            success:function(response) {
                                var resp = $.trim(response);
                                $("#selected_branches").html(resp);
                            }
                        });
                    } else {
                        $("#selected_branches").html("<option value=''>------- Select --------</option>");
                    }
                });
            });
            </script>
