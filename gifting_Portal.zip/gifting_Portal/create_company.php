<?php 
echo "ii";
//include './class/admin_invitation.php';
include('header.php');
include('db_functions.php');
$dbFunctions_obj = new dbFunctions();
$result = $dbFunctions_obj->getCompanylist();
?>
<div class="row rowfluidalignment">
    <div class="col-sm-12"> 
        <!-- Page Form Start -->
        <?php
        echo "<table class=\"user_history_table\">
            <tr>
                <th>Name</th>
                <th>Brances</th>
                <th>Action</th>
            </tr>";
            while($row = mysqli_fetch_array($result))
            {
                echo "<tr>";
                echo "<td>" . $row['company_name'] . "</td>";
                echo "<td>" . $row['branches'] . "</td>";
                echo "<td> <a href=create_company_post.php?id=".$row['id'].">Delete</td>";
                echo "</tr>";
            }
        echo "</table>";
        ?>
        <!-- Page Form End -->
    </div>
</div>
<div class='searchConteiner'>
    <div class='row rowfluidalignment'>
        <div class='col-sm-12'>
            <!-- Page Form Start -->
            <form id='eventDetails'  method='post' enctype="multipart/form-data" action="create_company_post.php">
                <!-- <h4>Invitaion Portal <h4> -->
                <div class='col-sm-12 widgetDescriptionForm'>
                    <div class='row'>
                        <h4 class='header_title'>Create Company/Brances</h4>
                        <div class='widgetDescriptionRow clearfix'>								
                            <fieldset class='col-sm-4 form-group'>
                                <label><span class='requiredFiled'>*</span>Company Name</label>
                                <input id='companyname' name='companyname' class='form-control' onblur='this.value=this.value.trim();' type='text' value='' maxlength='30' >
                                <div class='discriptionErrorMsg nameerror'>
                                </div>
                            </fieldset>
                            <fieldset class='col-sm-4 form-group'>
                                <label><span class='requiredFiled'>*</span>Brances(comma separted ex: Marathahalli,Madiwala,..)</label>
                                <textarea name='brances' id='brances' class='form-control'   ></textarea>
                                <div class='discriptionErrorMsg addresserror'>
                                </div>
                            </fieldset>
                            <fieldset class='col-sm-4 form-group'>
                                <div class='widgetSearchButton search-criteria'>
                                    <!-- <label>Search criteria : you can use wild characters (*,%) for search</label> -->
                                </div>
                                <div class='widgetSearchButton no-search-criteria'>	
                                    <input type='submit' value='Submit' name='submit_company' id='invitDatetime' class='btn btn-info cust-bttn submit'>
                                </div>
                            </fieldset>
                        </div>
                    </div>
                </div>
            <form>
        </div>
    </div>
</div>


                
                        
